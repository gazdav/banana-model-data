# vychadzame z pripraveneho suboru AnalyzaAlfaUprav.csv ulozeneho v udajeTilla/analyzaAlf


# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/AnalyzaAlf")

udaje<-read.csv("AnalyzaAlfaUprav.csv")
head(udaje)


# Define a named vector for renaming facets
facet_labels <- c(
  "ConsSavings" = "Consumers Savings",
  "Surplus" = "Seller Surplus",
  "utility" = "Utility",
  "PurchasingRatio" = "Purchasing Ratio"
)

# Define a common theme with increased axis and facet text sizes
custom_theme <- theme_minimal() +
  theme(
    axis.text.x = element_text(size = 12),  # Increase x-axis tick text size
    axis.text.y = element_text(size = 12),  # Increase y-axis tick text size
    axis.title.x = element_text(size = 14), # Increase x-axis title size
    axis.title.y = element_text(size = 14), # Increase y-axis title size
    strip.text = element_text(size = 15) # Increase facet titles
  )

# Scatterplot 1: alpha vs ConsSavings
p1 <- ggplot(udaje, aes(x = alpha, y = ConsSavings)) +
  geom_point(color = "black", alpha = 0.6,size=1.3) +
  geom_smooth(method = "lm", se = FALSE, color = "red", linetype = "solid") +  # Add regression line
  labs(
    title = "Alpha vs ConsSavings",
    x = "Alpha",
    y = "Consumer Savings"
  ) +
  custom_theme

# Scatterplot 2: alpha vs Surplus
p2 <- ggplot(udaje, aes(x = alpha, y = Surplus)) +
  geom_point(color = "black", alpha = 0.6,size=1.3) +
  geom_smooth(method = "lm", se = FALSE, color = "red", linetype = "solid") +  # Add regression line
  labs(
    title = "Alpha vs Surplus",
    x = "Alpha",
    y = "Surplus"
  ) +
  custom_theme

# Scatterplot 3: alpha vs Utility
p3 <- ggplot(udaje, aes(x = alpha, y = utility)) +
  geom_point(color = "black", alpha = 0.6,size=1.3) +
  geom_smooth(method = "lm", se = FALSE, color = "red", linetype = "solid") +  # Add regression line
  labs(
    title = "Alpha vs Utility",
    x = "Alpha",
    y = "Utility"
  ) +
  custom_theme

# Scatterplot 4: alpha vs PurchasingRatio
p4 <- ggplot(udaje, aes(x = alpha, y = PurchasingRatio)) +
  geom_point(color = "black", alpha = 0.6,size=1.3) +
  geom_smooth(method = "lm", se = FALSE, color = "red", linetype = "solid") +  # Add regression line
  #  labs(
  #    title = "Alpha vs PurchasingRatio",
  #    x = "Alpha",
  #    y = "Purchasing Ratio"
  #  ) +
  custom_theme

# Arrange the plots in a 2x2 grid
(p1 | p2) / (p3 | p4)

# Modify the facet wrap plot as well
udaje_long <- tidyr::pivot_longer(udaje, cols = c(ConsSavings, Surplus, utility, PurchasingRatio), names_to = "Variable", values_to = "Value")


# Create the plot with updated facet labels
ggplot(udaje_long, aes(x = alpha, y = Value)) +
  geom_point(alpha = 0.6,size=1.3) +
  geom_smooth(method = "lm", se = FALSE, color = "red", linetype = "solid") +
  facet_wrap(~Variable, scales = "free_y", labeller = as_labeller(facet_labels)) +  # Apply new facet titles
  labs(x = "Alpha", y = "Value") +
  custom_theme

#############################




