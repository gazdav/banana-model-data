#
#     P o r o v n a n i e   s tradicnymi cenami
#
#   dataframy su
#
#                     1 filtered_data1   hromadna - 40 simulacii s tradicnym ocenovanim
#
#
#########################################################################
#    n a d c i t a v a n i e   suborov
#                    vysledkom je combined_weekly_data_summary.csv
#                         ktory ma nasledovne stlpce
#"S","NewPriceWeek","SellerWeeklyProfits","SellerSurplus","WeeklyTotalProductSold","WeeklyCustomerSavings",
#"DAY_1","DAY_2","DAY_3","DAY_4","DAY_5","DAY_6","DAY_7","Customer_1","Customer_2",...
########################################################################################
# Source with a local environment
# Clear environment
rm(list = ls())
cat("\014")
# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/TradicneCeny")
# List all CSV files
#csv_files <- list.files(path = ".", pattern = "^weekly_data.*\\.csv$", full.names = FALSE)
csv_files <- list.files(path = ".", pattern = "^weeklyPrice_simulation_together_traditional_.*\\.csv$", full.names = FALSE)
# Initialize an empty data frame for combining data
konecne <- NULL
# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne)
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne))) {
      temp_data <- temp_data[-1, ]
    }
    # Append to the combined data frame
    konecne <- rbind(konecne, temp_data)
  }
}
######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be,
# if the column will be located as the first in the data.frame
#####################################################
# Add the new column "S" with a default value (e.g., NA or any value)
konecne$S <- NA  # Replace NA with a specific value if needed
# Move "S" to the first position
konecne <- konecne[, c("S", setdiff(names(konecne), "S"))]
konecne$S <- ceiling(seq_len(nrow(konecne)) / 28)
# Teraz ceny dynamicke
# List all CSV files
rm(csv_files)
csv_files <- list.files(path = ".", pattern = "^weeklyPrice_simulation_together_dynamic_.*\\.csv$", full.names = FALSE)
# Initialize an empty data frame for combining data
konecne2 <- NULL
rm(temp_data)
# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne2 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne2)
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne2))) {
      temp_data <- temp_data[-1, ]
    }
    # Append to the combined data frame
    konecne2 <- rbind(konecne2, temp_data)
  }
}






######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be,
# Add the new column "S" with a default value (e.g., NA or any value)
konecne2$S <- NA  # Replace NA with a specific value if needed
# Move "S" to the first position
konecne2 <- konecne2[, c("S", setdiff(names(konecne2), "S"))]
konecne2$S <- ceiling(seq_len(nrow(konecne2)) / 28)




########################################################
#
#    v y t v o r e n i e   z a v e r e c n e h o    suboru
#
#########################################################
#  niekde predtym som urobil chybu a subory dynamic su fixne a naopak
# v tychto 4 prikazoch to robim opat naopak, aby som to dal do poriadku
revenues_tradicne <- as.numeric(as.character(konecne2$SellerWeeklyProfits))
revenues_dynamicke <- as.numeric(as.character(konecne$SellerWeeklyProfits))
waste_tradicne <- 200-as.numeric(as.character(konecne2$WeeklyTotalProductSold))
waste_dynamicke <- -as.numeric(as.character(konecne$WeeklyTotalProductSold))+200


konecne_final <- data.frame(cbind(as.numeric(as.character(konecne$S)),as.numeric(as.character(konecne$NewPriceWeek)),revenues_tradicne,revenues_dynamicke,waste_tradicne,waste_dynamicke))
colnames(konecne_final)<-c("S","Week","revenues_tradicne","revenues_dynamicke","waste_tradicne","waste_dynamicke")







############################################################################################
# udaje pre posledny obrazok
#                                  Consumers' utility
#
############################################################################################

data.uzitky <- read.csv("AnalyzaAlfaUprav.csv")


# Musime si pripravit subor s uzitkami za jednotlivych spotrebitelov, ktore potom napocitame
#  po tyzdnoch
#
#
# vychadzame zo suborov
#      konecne
#      data.uzitky   v prvom stlpci su tu alfy spotrebitelov  data.uzitky$alpha
#     
#

#               D Y N A M I C K E     C E N Y   
#                    vysledok je matica A

# conversion of all the data to numeric format

# v konecne su stlpce 14:213 spotrebitelia
konecne <- data.frame(lapply(konecne, function(x) as.numeric(as.character(x))))
 
#  teraz pretriedenie subor konecne
konecne <- konecne[order(konecne$NewPriceWeek, konecne$S), ]




A <- matrix(rep(0,times=1092),ncol=28)   # kumulovane uzitky za jednotlive tyzdne (stlpce) a jednotlive simulacie (riadky)
k <- 1
quality <- c(63,60,55,48,39,28,15)
for (tyzde in 1:28)  {
  for (simul in 1:39) {
    for (con in 14:213) {
      if (konecne[k,con] != 8) {
      uzitok_spotrebitela <- data.uzitky$alpha[con-13]*quality[konecne[k,con]]+(1-data.uzitky$alpha[con-13])*(100-konecne[k,konecne[k,con]+6])       
      } else {
        uzitok_spotrebitela <- 50   # 50 je  Rho * M
      }
     A[simul,tyzde] <- A[simul,tyzde] + uzitok_spotrebitela
    }
    k <- k + 1
   }
}




#

#               F I X N E     C E N Y
#                    vysledok je matica A2


# conversion of all the data to numeric format

# v konecne su stlpce 14:213 spotrebitelia
konecne2 <- data.frame(lapply(konecne2, function(x) as.numeric(as.character(x))))

#  teraz pretriedenie subor konecne
konecne2 <- konecne2[order(konecne2$NewPriceWeek, konecne2$S), ]



A2 <- matrix(rep(0,times=1092),ncol=28)   # kumulovane uzitky za jednotlive tyzdne (stlpce) a jednotlive simulacie (riadky)
k <- 1
quality <- c(63,60,55,48,39,28,15)
for (tyzde in 1:28)  {
  for (simul in 1:39) {
    for (con in 14:213) {
      if (konecne2[k,con] != 8) {
           uzitok_spotrebitela <- data.uzitky$alpha[con-13]*quality[konecne2[k,con]]+(1-data.uzitky$alpha[con-13])*(100-konecne2[k,konecne2[k,con]+6])       
             } else {
           uzitok_spotrebitela <- 50   # 50 je  Rho * M
            }
      A2[simul,tyzde] <- A2[simul,tyzde] + uzitok_spotrebitela
      print(A2[simul,tyzde])
    }
    print(A2[simul,tyzde])
    k <- k + 1
    print(k)
  }
}

##########################################################
#
#                      Prenos do konecne_final
#
##########################################################

#   dodanie stlpcov s uzitkami
konecne_final$utilitiestrad <- rep(0, nrow(konecne_final))
konecne_final$utilitiesdyn <- rep(0, nrow(konecne_final))
#   pretriedenie suboru
konecne_final <- konecne_final[order(konecne_final$Week,konecne_final$S),]

k <- 1
for (i in 1:28) {
  for (j in 1:39){
    konecne_final$utilitiestrad[k] <- A2[j,i]
    konecne_final$utilitiesdyn[k] <- A[j,i]
    k <- k+1
  }
}























#########################
# dodatocna analyza s realizacnymi cenami


############################################################################################
# udaje pre posledny obrazok
#                                  Consumers' prices
#
############################################################################################

data.uzitky <- read.csv("AnalyzaAlfaUprav.csv")


# Musime si pripravit subor s uzitkami za jednotlivych spotrebitelov, ktore potom napocitame
#  po tyzdnoch
#
#
# vychadzame zo suborov
#      konecne
#      data.uzitky   v prvom stlpci su tu alfy spotrebitelov  data.uzitky$alpha
#     
#

#               D Y N A M I C K E     C E N Y   
#                    vysledok je matica B

# conversion of all the data to numeric format

# v konecne su stlpce 14:213 spotrebitelia
konecne <- data.frame(lapply(konecne, function(x) as.numeric(as.character(x))))

#  teraz pretriedenie subor konecne
konecne <- konecne[order(konecne$NewPriceWeek, konecne$S), ]




B <- matrix(rep(0,times=1092),ncol=28)   # priem. ceny za jednotlive tyzdne (stlpce) a jednotlive simulacie (riadky)
k <- 1
PocetPredajov <- 0
CenaDyn <- 0
CenaDynPriemerna<-0
quality <- c(63,60,55,48,39,28,15)
for (tyzde in 1:28)  {
  for (simul in 1:39) {
    for (con in 14:213) {
#      print(paste("k=",k,"simul=",simul,"tyzde=",tyzde,"con=",con,"CenaDynPriemerna=",CenaDynPriemerna,"PocetPredajov=",PocetPredajov))
      if (konecne[k,con] != 8) {
        CenaDyn <- CenaDyn + konecne[k,konecne[k,con]+6] 
        PocetPredajov <- PocetPredajov + 1
        CenaDynPriemerna <- CenaDyn/PocetPredajov
      } 
    }
    B[simul,tyzde] <- CenaDynPriemerna
    PocetPredajov <- 0
    CenaDyn <- 0
    k <- k + 1
  }
}



#

#               F I X N E     C E N Y
#                    vysledok je matica B2


# conversion of all the data to numeric format

# v konecne su stlpce 14:213 spotrebitelia
konecne2 <- data.frame(lapply(konecne2, function(x) as.numeric(as.character(x))))

#  teraz pretriedenie subor konecne
konecne2 <- konecne2[order(konecne2$NewPriceWeek, konecne2$S), ]



B2 <- matrix(rep(0,times=1092),ncol=28)   # kumulovane uzitky za jednotlive tyzdne (stlpce) a jednotlive simulacie (riadky)
k <- 1
PocetPredajov <- 0
CenaDyn <- 0
quality <- c(63,60,55,48,39,28,15)
for (tyzde in 1:28)  {
  for (simul in 1:39) {
    for (con in 14:213) {
      if (konecne2[k,con] != 8) {
        CenaDyn <- CenaDyn + konecne2[k,konecne2[k,con]+6] 
        PocetPredajov <- PocetPredajov + 1
        CenaDynPriemerna <- CenaDyn/PocetPredajov
      } 
    }
    B2[simul,tyzde] <- CenaDynPriemerna
    PocetPredajov <- 0
    CenaDyn <- 0
    k <- k + 1
  }
}

##########################################################
#
#                      Prenos do konecne_final
#
##########################################################

#   dodanie stlpcov s uzitkami
konecne_final$utilitiestrad <- rep(0, nrow(konecne_final))
konecne_final$utilitiesdyn <- rep(0, nrow(konecne_final))
# dodanie stlpcov s cenami
konecne_final$cenytrad <- rep(0, nrow(konecne_final))
konecne_final$cenydyn <- rep(0, nrow(konecne_final))
#   pretriedenie suboru
konecne_final <- konecne_final[order(konecne_final$Week,konecne_final$S),]

k <- 1
for (j in 1:28) {
  for (i in 1:39){
    konecne_final$utilitiestrad[k] <- A2[i,j]
    konecne_final$utilitiesdyn[k] <- A[i,j]
    konecne_final$cenytrad[k] <- B2[i,j]
    konecne_final$cenydyn[k] <- B[i,j]    
    k <- k+1
  }
}


#rm(list(A,A2,B,B2,temp_data,CenaDyn,CenaDynPriemerna,con,csv_files,i,j,k,PocetPredajov,quality,revenues_dynamicke,revenues_tradicne,simul,tyzde,uzitok_spotrebitela,waste_dynamicke,waste_tradicne))




















##########################################################################
#
#             R O B E N I E   O B R A Z K O V
#
##########################################################################




#################################################################################
#
#          obrazok podla revenues

# Convert to long format

library(ggplot2)
library(tidyr)
library(dplyr)

combined_prac <- konecne_final %>%
  arrange(S,Week)

# Convert to long format
combined_long <- combined_prac %>%
  pivot_longer(cols = c(revenues_dynamicke, revenues_tradicne), 
               names_to = "Pricing_Model", 
               values_to = "Revenues")

# Replace column values for better labels
combined_long$Pricing_Model <- recode(combined_long$Pricing_Model, 
                                      revenues_tradicne = "Optimized Traditional Pricing with 50% Discount", 
                                      revenues_dynamicke = "Dynamic Pricing")

# Reorder factor levels to swap positions in boxplot pairs
combined_long$Pricing_Model <- factor(combined_long$Pricing_Model, 
                                      levels = c("Optimized Traditional Pricing with 50% Discount", "Dynamic Pricing"))

ggplot(combined_long, aes(x = factor(Week), y = Revenues, fill = Pricing_Model)) +
  geom_boxplot(position = position_dodge(width = 0.8), width=0.6, alpha = 0.6) +
  scale_fill_manual(values = c("Optimized Traditional Pricing with 50% Discount" = "white", 
                              "Dynamic Pricing" = "darkgrey")) +
  labs(x = "Week",
       y = "Revenues",
       fill = "") +
  theme_minimal() +
  theme(    axis.text.x = element_text(angle = 0, hjust = 1, size = 10),  # X-axis text size
            axis.text.y = element_text(size = 10),  # Y-axis text size
            axis.title.x = element_text(size = 15),  # X-axis label size
            axis.title.y = element_text(size = 15),  # Y-axis label size
            legend.position = "none",                    # Move legend below the plot
            legend.text = element_text(size = 14),         # Increase legend text size
            legend.title = element_text(size = 16, face = "bold"))  # Increase and bold legend title





#################################################################################
#
#          obrazok podla utilities

# Convert to long format

combined_prac <- konecne_final %>%
  arrange(S,Week)

# Convert to long format
combined_long <- combined_prac %>%
  pivot_longer(cols = c(utilitiesdyn, utilitiestrad), 
               names_to = "Pricing_Model", 
               values_to = "Utilities")

# Replace column values for better labels
combined_long$Pricing_Model <- recode(combined_long$Pricing_Model, 
                                      utilitiestrad = "Optimized Traditional Pricing with 50% Discount", 
                                      utilitiesdyn = "Dynamic Pricing")

# Reorder factor levels to swap positions in boxplot pairs
combined_long$Pricing_Model <- factor(combined_long$Pricing_Model, 
                                      levels = c("Optimized Traditional Pricing with 50% Discount", "Dynamic Pricing"))

ggplot(combined_long, aes(x = factor(Week), y = Utilities, fill = Pricing_Model)) +
  geom_boxplot(position = position_dodge(width = 0.8),width=0.6, alpha = 0.6) +
  scale_fill_manual(values = c("Optimized Traditional Pricing with 50% Discount" = "white", 
                               "Dynamic Pricing" = "darkgrey")) +
  labs(x = "Week",
       y = "Utilities",
       fill = "") +
  theme_minimal() +
  theme(    axis.text.x = element_text(angle = 0, hjust = 1, size = 10),  # X-axis text size
            axis.text.y = element_text(size = 10),  # Y-axis text size
            axis.title.x = element_text(size = 15),  # X-axis label size
            axis.title.y = element_text(size = 15),  # Y-axis label size
            legend.position = "bottom",                    # Move legend below the plot
            legend.text = element_text(size = 14),         # Increase legend text size
            legend.title = element_text(size = 16, face = "bold"))  # Increase and bold legend title







#################################################################################
#
#          obrazok podla prices

# Convert to long format

combined_prac <- konecne_final %>%
  arrange(S,Week)

# Convert to long format
combined_long <- combined_prac %>%
  pivot_longer(cols = c(cenydyn, cenytrad), 
               names_to = "Pricing_Model", 
               values_to = "Prices")

# Replace column values for better labels
combined_long$Pricing_Model <- recode(combined_long$Pricing_Model, 
                                      cenytrad = "Optimized Traditional Pricing with 50% Discount", 
                                      cenydyn = "Dynamic Pricing")

# Reorder factor levels to swap positions in boxplot pairs
combined_long$Pricing_Model <- factor(combined_long$Pricing_Model, 
                                      levels = c("Optimized Traditional Pricing with 50% Discount", "Dynamic Pricing"))

ggplot(combined_long, aes(x = factor(Week), y = Prices, fill = Pricing_Model)) +
  geom_boxplot(position = position_dodge(width = 0.8),width=0.6, alpha = 0.6) +
  scale_fill_manual(values = c("Optimized Traditional Pricing with 50% Discount" = "white", 
                               "Dynamic Pricing" = "darkgrey")) +
  labs(x = "Week",
       y = "Sales Prices",
       fill = "") +
  theme_minimal() +
  theme(    axis.text.x = element_text(angle = 0, hjust = 1, size = 10),  # X-axis text size
            axis.text.y = element_text(size = 10),  # Y-axis text size
            axis.title.x = element_text(size = 15),  # X-axis label size
            axis.title.y = element_text(size = 15),  # Y-axis label size
        legend.position = "none",                    # Move legend below the plot
        legend.text = element_text(size = 14),         # Increase legend text size
        legend.title = element_text(size = 16, face = "bold"))  # Increase and bold legend title



############################################
# Sorting the dataframe by "Week" (primary key) and "S" (secondary key)
combined_prac <- konecne_final %>%
  arrange(S,Week)

library(ggplot2)
library(tidyr)
library(dplyr)

# Convert to long format
combined_long <- combined_prac %>%
  pivot_longer(cols = c(waste_dynamicke, waste_tradicne), 
               names_to = "Pricing_Model", 
               values_to = "Waste")

# Replace column values for better labels
combined_long$Pricing_Model <- recode(combined_long$Pricing_Model, 
                                      waste_tradicne = "Optimized Traditional Pricing with 50% Discount", 
                                      waste_dynamicke = "Dynamic Pricing")

# Reorder factor levels to swap positions in boxplot pairs
combined_long$Pricing_Model <- factor(combined_long$Pricing_Model, 
                                      levels = c("Optimized Traditional Pricing with 50% Discount", "Dynamic Pricing"))

ggplot(combined_long, aes(x = factor(Week), y = Waste, fill = Pricing_Model)) +
  geom_boxplot(position = position_dodge(width = 0.8), width=0.6, alpha = 0.6) +
  scale_fill_manual(values = c("Optimized Traditional Pricing with 50% Discount" = "white", 
                               "Dynamic Pricing" = "darkgrey")) +
  labs(x = "Week",
       y = "Waste",
       fill = "") +
  theme_minimal() +
  theme(    axis.text.x = element_text(angle = 0, hjust = 1, size = 10),  # X-axis text size
            axis.text.y = element_text(size = 10),  # Y-axis text size
            axis.title.x = element_text(size = 15),  # X-axis label size
            axis.title.y = element_text(size = 15),  # Y-axis label size
            legend.position = "bottom",                    # Move legend below the plot
            legend.text = element_text(size = 14),         # Increase legend text size
            legend.title = element_text(size = 16, face = "bold"))  # Increase and bold legend title


















