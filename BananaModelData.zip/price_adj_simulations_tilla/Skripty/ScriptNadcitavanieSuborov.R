#########################################################################
#    n a d c i t a v a n i e   suborov
#                    vysledkom je combined_weekly_data_summary.csv
#                         ktory ma nasledovne stlpce
#"S","NewPriceWeek","SellerWeeklyProfits","SellerSurplus","WeeklyTotalProductSold","WeeklyCustomerSavings",
#"DAY_1","DAY_2","DAY_3","DAY_4","DAY_5","DAY_6","DAY_7","Customer_1","Customer_2",...
########################################################################################




# Source with a local environment
# Clear environment
rm(list = ls())
cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla")


# List all CSV files
csv_files <- list.files(pattern = "weekly_data_summary_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne <- rbind(konecne, temp_data)
  }
}

######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be, 
# if the column will be located as the first in the data.frame
#####################################################

# Add the new column "S" with a default value (e.g., NA or any value)
konecne$S <- NA  # Replace NA with a specific value if needed

# Move "S" to the first position
konecne <- konecne[, c("S", setdiff(names(konecne), "S"))]
konecne$S <- ceiling(seq_len(nrow(konecne)) / 100)

################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyMostChoosenDayPerCustomer_imulation_1.csv
#    - > do dataframe konecny2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla")

# List all CSV files
csv_files <- list.files(pattern = "weeklyMostChoosenDayPerCustomer_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne2 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne2 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne2)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne2))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne2 <- rbind(konecne2, temp_data)
  }
}


################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyPrice_simulation_i.csv
#    - > do dataframe konecne2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla")

# List all CSV files
csv_files <- list.files(pattern = "weeklyPrice_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne3 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne3 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne3)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne3))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne3  <- rbind(konecne3, temp_data)
  }
}




#########################################
#  vlozenie vsetkeho do jedneho suboru
#########################################

# Combine the data frames column-wise
combined <- cbind(konecne, konecne3, konecne2)
combined$SellerWeeklyProfits  <- as.numeric(combined$SellerWeeklyProfits)+6000

# Inspect the result
head(combined)

############################################
#konverzia na ciselny tvar dat
combined_prac <- combined

for (i in 1:dim(combined_prac)[2]){
  combined_prac[,i] <- as.numeric(combined_prac[,i])
}

############################################



########################################################
# Save the combined data to a CSV file
write.csv(combined, "combined_weekly_data_summary.csv", row.names = FALSE)


#################################################
#  mazanie pracovnych premenn7ch a tabuliek

rm(konecne)
rm(konecne2)
rm(konecne3)
rm(i)
rm(temp_data)

