

# Source with a local environment
# nadcitavanie suborov csv a ich prevod do data.frame nazvaneho "combined"
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla/Skripty")
#source("ScriptNadcitavanieSuborov.R", local = TRUE)


# udaje su nadcitane 


#####################################################################
#
#              prva rozsiahla analyza - vypoctova stabilita (convergencia)
# budeme riesi5 len prvych 20 kol simulacie


# vytvaram pracovny subor combined, pretože do neho budem robiť zásahy, na 
# zaciatku to prekonvertujem do ciselneho formatu

#combined_prac <- combined

#for (i in 1:dim(combined_prac)[2]){
#  combined_prac[,i] <- as.numeric(combined_prac[,i])
#}

################# L I B R A R I E S    #########################
library(ggplot2)
library(dplyr)
library(tidyr)
library(moments)  # For skewness and kurtosis
library(xtable) 
library(dendextend)
library(reshape)
















#############################################################
#
#            P i l o t   s i m u l a t i o n
#
############################################################



# Sorting the dataframe by "NewPriceWeek" (primary key) and "S" (secondary key)
combined_prac <- combined_prac %>%
  arrange(NewPriceWeek, S)

# Filter data to include only NewPriceWeek values from 1 to n and S==1
filtered_data <- combined_prac %>%
  filter(NewPriceWeek %in% 1:100) %>%
  filter(S==1)
filtered_data$SellerWeeklyProfits <- as.numeric(filtered_data$SellerWeeklyProfits)

############################################################
# analyza of WeeklyTotalProductSold

############################################################

# Boxplot at first

boxplot_data <- data.frame(Value = filtered_data$WeeklyTotalProductSold)



#########################################################


# Generate smoothed splines for the "WeeklyToltalProductSold"

smooth_spline <- smooth.spline(x = filtered_data$NewPriceWeek , y = filtered_data$WeeklyTotalProductSold, spar = 0.45)


# Extract x and y values and convert to data frames

spline_data <- data.frame(NewPriceWeek = smooth_spline$x, SmoothedMedian = smooth_spline$y)


line_data_s1 <- filtered_data #%>%

# Create the boxplots with the smoothed spline curves and added lines
ggplot(data = line_data_s1, aes(x = NewPriceWeek, y = WeeklyTotalProductSold)) +
  # Boxplot for the red line (Variable1) at x = 0
  geom_boxplot(data = boxplot_data, aes(x = -6.5, y = Value),  # Dummy x-axis position
               fill = "lightgrey", color = "black", width = 4) +
  # Add smoothed line graphs

  geom_line(data = spline_data, aes(x = NewPriceWeek, y = SmoothedMedian, group = 1),
            color = "black", linewidth = 0.5, linetype = "dashed") +  # Smoothed Median

  # Add red line for S == 1
  geom_line(data = line_data_s1, aes(x = NewPriceWeek, y = WeeklyTotalProductSold, group = 1),
            color="red", linewidth = 0.6) +
  # Add blue line for S == 5
  # geom_line(data = line_data_s5, aes(x = NewPriceWeek, y = WeeklyTotalProductSold, group = 1),
  #          color = "blue", linewidth = 0.8) +
  # Add a vertical line to separate the boxplot and line graph
  geom_vline(xintercept = 0, color = "darkgrey", linetype = "solid", linewidth = 1) +
  labs(
 #   title = "Volume of Weekly Sold Goods",
    x = "Week",
    y = "Volume"
  ) +
  theme_minimal() +
  theme(
    axis.line = element_line(size = 1, color = "darkgrey"),  # axis lines
    axis.text = element_text( size = 12),     # axis labels
    axis.title = element_text( size = 14),    # Bold axis titles
    axis.ticks = element_line(size = 1, color = "darkgrey"), # Bold axis ticks
    axis.text.x = element_text(angle = 0, hjust = 1)       # Rotate x-axis labels
  ) + 
  theme(legend.position = "bottom",                    # Move legend below the plot
        legend.text = element_text(size = 14),         # Increase legend text size
        legend.title = element_text(size = 16, face = "bold"))  # Increase and bold legend title


rm(smooth_spline)
rm(line_data_s1)
rm(spline_data)




################################################################
# statistical summary
# Assuming filtered_data is already defined
# Statistics calculation
# Prepare the WeeklyTotalProductSold column, omitting the first observation
wts <- filtered_data$WeeklyTotalProductSold[-1]  # Drop the first observation

# Calculate lag-1 autocorrelation using acf() function
acf_value <- acf(wts, lag.max = 1, plot = FALSE)$acf[2]  # Extract the lag-1 autocorrelation

# Statistics calculation
stats_summary <- data.frame(
  Statistic = c("Mean", "Median", "Min", "Max", "Standard Deviation", "Skewness", "Kurtosis", "Lag-1 Autocorrelation"),
  Value = c(
    mean(filtered_data$WeeklyTotalProductSold, na.rm = TRUE),
    median(filtered_data$WeeklyTotalProductSold, na.rm = TRUE),
    min(filtered_data$WeeklyTotalProductSold, na.rm = TRUE),
    max(filtered_data$WeeklyTotalProductSold, na.rm = TRUE),
    sd(filtered_data$WeeklyTotalProductSold, na.rm = TRUE),
    skewness(filtered_data$WeeklyTotalProductSold, na.rm = TRUE),
    kurtosis(filtered_data$WeeklyTotalProductSold, na.rm = TRUE),
    acf_value
  )
)

# Convert the summary table to LaTeX format using xtable
latex_table <- xtable(stats_summary, caption = "Statistical Summary of WeeklyTotalProductSold with Lag-1 Autocorrelation")

# Print LaTeX code in the console
print(latex_table, include.rownames = FALSE, caption.placement = "top")

# Optionally export to a .tex file
write(print(latex_table, include.rownames = FALSE, caption.placement = "top"), 
      file = "summary_statistics.tex")
rm(wts)
rm(acf_value)
rm(latex_table)
rm(stats_summary)








############################################################
# analyza of SellerWeeklyRevenues

############################################################

# Boxplot at first

boxplot_data <- data.frame(Value = filtered_data$SellerWeeklyProfits)





#########################################################


# Generate smoothed splines for the "SellerWeeklyProfits"

smooth_spline <- smooth.spline(x = filtered_data$NewPriceWeek , y = filtered_data$SellerWeeklyProfits, spar = 0.45)


# Extract x and y values and convert to data frames

spline_data <- data.frame(NewPriceWeek = smooth_spline$x, SmoothedMedian = smooth_spline$y)


line_data_s1 <- filtered_data #%>%

# Create the boxplots with the smoothed spline curves and added lines
ggplot(data = line_data_s1, aes(x = NewPriceWeek, y = SellerWeeklyProfits)) +
  # Boxplot for the red line (Variable1) at x = 0
  geom_boxplot(data = boxplot_data, aes(x = -6.5, y = Value),  # Dummy x-axis position
               fill = "lightgrey", color = "black", width = 4) +
  # Add smoothed line graphs
  
  geom_line(data = spline_data, aes(x = NewPriceWeek, y = SmoothedMedian, group = 1),
            color = "black", linewidth = 0.5, linetype = "dashed") +  # Smoothed Median
  
  # Add red line for S == 1
  geom_line(data = line_data_s1, aes(x = NewPriceWeek, y = SellerWeeklyProfits, group = 1),
            color="red", linewidth = 0.6) +
  # Add blue line for S == 5
  # geom_line(data = line_data_s5, aes(x = NewPriceWeek, y = SellerWeeklyProfits, group = 1),
  #          color = "blue", linewidth = 0.8) +
  # Add a vertical line to separate the boxplot and line graph
  geom_vline(xintercept = 0, color = "darkgrey", linetype = "solid", linewidth = 1) +
  labs(
    title = "",
    x = "Week",
    y = "Revenues"
  ) +
  theme_minimal() +
  theme(
    axis.line = element_line(size = 1, color = "darkgrey"),  # axis lines
    axis.text = element_text( size = 12),     # axis labels
    axis.title = element_text( size = 14),    # Bold axis titles
    axis.ticks = element_line(size = 1, color = "darkgrey"), # Bold axis ticks
    axis.text.x = element_text(angle = 0, hjust = 1)       # Rotate x-axis labels
  )

rm(boxplot_data)
rm(smooth_spline)
rm(spline_data)






################################################################

###########    C   L   U   S   T   E   R       analysis        #####

# Load required libraries
library(ggplot2)   # For plotting if needed
library(dendextend) # For enhanced dendrogram visuals
library(dplyr)      # For data manipulation


# Step 0: Number of clusters NumberOfClust
NumberOfClust<-6

# Step 1: Prepare the data
# Assuming "filtered_data" contains the columns DAY_1 to DAY_7
clustering_data <- filtered_data %>%
  select(DAY_1:DAY_7,SellerWeeklyProfits) %>%
  na.omit()  # Remove rows with missing values (if any)

# Step 2: Scale the data (recommended for clustering)
scaled_data <- scale(clustering_data[,1:7])

# Step 3: Compute the distance matrix (Euclidean distance)
distance_matrix <- dist(scaled_data, method = "euclidean")

# Step 4: Perform hierarchical clustering
hclust_result <- hclust(distance_matrix, method = "ward.D2")  # "ward.D2" minimizes cluster variance

# Step6: clasical dendogram

# Plot the dendrogram
plot(hclust_result, 
     main = "Enhanced Dendrogram with 6 Clusters", 
     xlab = "", 
     ylab = "Height", 
     axes = TRUE, 
     labels = FALSE,  # Suppress branch labels
     sub=" ")

# Add a red horizontal line at the height that creates 6 clusters
abline(h = 8.3, col = "red", lwd = 1)  # Adjust `h` to match your dendrogram's cluster height

# Add vertical dashed lines
abline(v = c(1.5, 26.5, 38.5,58.5,79.5), col = "red", lty = 2, lwd = 1.5)  # Adjust `v` positions as needed

# Add text annotations
text(x = -4, y = 12, labels = "Cl.1", col = "red", cex = 1.2, pos = 4)  # Example position for "Cluster 1"
text(x = 8, y = 12, labels = "Cluster 2", col = "red", cex = 1.2, pos = 4)  # Example position for "Cluster 2"
text(x = 26.5, y = 12, labels = "Cluster 3", col = "red", cex = 1.2, pos = 4)  # Example position for "Cluster 2"
text(x = 45, y = 12, labels = "Cluster 4", col = "red", cex = 1.2, pos = 4)  # Example position for "Cluster 2"
text(x = 62, y = 12, labels = "Cluster 5", col = "red", cex = 1.2, pos = 4)  # Example position for "Cluster 2"
text(x = 82, y = 12, labels = "Cluster 6", col = "red", cex = 1.2, pos = 4)  # Example position for "Cluster 2"


# Step 6: Add cluster assignments to the original data
clusters <- cutree(hclust_result, k = NumberOfClust)   # oznacenie, ktory riadok z filtered_data zodpoveda 
                                                        # ktoremu clusteru, lepsie to je vidiet v "clustering_results"

clustering_results <- clustering_data %>%
  mutate(Cluster = as.factor(clusters))  # Add cluster labels to the data

# Step 7: Identify the representative (closest to centroid) for each cluster
cluster_representatives <- data.frame()

# Loop through each cluster to calculate the centroid and find the closest member
for (i in 1:NumberOfClust) {
  # Subset the data for the current cluster
  current_cluster <- clustering_results %>% filter(Cluster == i) %>% select(-Cluster)
  
  # Compute the centroid of the cluster
  centroid <- colMeans(current_cluster)
  
  # Compute Euclidean distances to the centroid
  distances <- apply(current_cluster, 1, function(row) sqrt(sum((row - centroid)^2)))
  
  # Identify the closest observation
  closest_row <- clustering_results %>% 
    filter(Cluster == i) %>% 
    slice(which.min(distances))
  
  # Append the closest row to the results
  cluster_representatives <- rbind(cluster_representatives, closest_row)
}

# Step 8: Print the cluster representatives
print("Cluster Representatives Closest to Centroids:")
print(cluster_representatives)

# Optional: View the clustered data
#head(clustering_results)


# ADJUSTMENT THE dataframe cluster_representatives by appending the column with revenues.

#profits <- cluster_representatives$Revenues

# Add the new column to the cluster_representatives dataframe
#cluster_representatives <- cluster_representatives %>%
#  mutate(NewColumn = profits)

colnames(cluster_representatives) <- c("Mon","Tue","Wed","Thu","Fri","Sat","Sun","Revenues","Cluster")

# View the updated dataframe

print(cluster_representatives)

# Load the xtable package   tabulka s reprezentatmi clustrov a ich cenami
library(xtable)

# Assuming 'cluster_representatives' is your data frame
# Convert the data frame to a LaTeX table
latex_table <- xtable(cluster_representatives, 
                      caption = "Cluster Representatives", 
                      label = "tab:cluster_representatives")

# Print the LaTeX table to the console (or save it to a file)
print(latex_table, 
      include.rownames = FALSE,   # Exclude row names
      caption.placement = "top",  # Place caption above the table
      table.placement = "ht")     # Table placement (here)

# Optional: Export to a .tex file
write(print(latex_table, include.rownames = FALSE), 
      file = "cluster_representatives.tex")

#             KONIEC
########################################################################



#   nefungujuce

# Filter rows where NewPriceWeek == 16
#filtered_data <- combined_prac %>%
#  filter(S == 1)

# Select columns 14 through 213 and pivot them into a long format
#long_data <- filtered_data %>%
#  select(14:213) %>%
#  pivot_longer(cols = everything(), names_to = "Variable", values_to = "Value")

# Convert values to numeric (if needed)
#long_data$Value <- as.numeric(long_data$Value)




#####################################################################
#   P R I C E S   I N   D A Y S
#####################################################################

# Map day names for better labeling
#day_labels <- c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
#long_data <- long_data %>%
#  mutate(Day = factor(Day, levels = c("DAY_1", "DAY_2", "DAY_3", "DAY_4", "DAY_5", "DAY_6", "DAY_7"), 
#                      labels = day_labels))

# Create the boxplot
#ggplot(long_data, aes(x = Day, y = Value)) +
#  geom_boxplot(fill = "lightgrey", color = "black") +
#  labs(
#    title = "Price Boxplots for Each Day",
#    x = "Day of the Week",
#    y = "Values"
#  ) +
#  theme_minimal() +
#  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for readability



###############################################################
# pilot simulation - histogram of the prices
#############################################
# Reshape the data into long format
long_data <- filtered_data %>%
  pivot_longer(
    cols = DAY_1:DAY_7,  # Select the 7 columns
    names_to = "Day",  # New column for days
    values_to = "Value"  # New column for values
  )

# Map day names for better labeling
day_labels <- c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
long_data <- long_data %>%
  mutate(Day = factor(Day, levels = c("DAY_1", "DAY_2", "DAY_3", "DAY_4", "DAY_5", "DAY_6", "DAY_7"), 
                      labels = day_labels))

# Data for the smooth curve
curve_data <- data.frame(
  Day = factor(c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"), levels = day_labels),
  Value = c(63, 60, 55, 48, 39, 28, 15)
)

# Create the boxplot with the red smooth curve
ggplot(long_data, aes(x = Day, y = Value)) +
  geom_boxplot(fill = "lightgrey", color = "black",width=0.4) +  # Boxplots
  geom_line(data = curve_data, aes(x = Day, y = Value, group = 1), color = "red", linewidth = 0.7) +  # Red smooth curve
  geom_point(data = curve_data, aes(x = Day, y = Value), color = "red", size = 0.5) +  # Red points for the curve
  labs(
    x = "Day of the Week",
    y = "Prices"
  ) +
  scale_y_continuous(limits = c(0, 100)) +  # Set y-axis limits to [0,100]
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 0.5, size = 21),  # X-axis text size
    axis.text.y = element_text(size = 21),  # Y-axis text size
    axis.title.x = element_text(size = 25),  # X-axis label size and bold, face = "bold"
    axis.title.y = element_text(size = 25)   # Y-axis label size and bold
  ) 
#########################################################################################
#
# r o z d e l e n i e   p o c e t n o s t i   kedy sa nakupuje
#
#########################################################################################

############################################
#konverzia na ciselny tvar dat
#combined_prac <- combined

##for (i in 1:dim(combined_prac)[2]){
#  combined_prac[,i] <- as.numeric(combined_prac[,i])
#}

############################################

# H I S T O G R A M   of the day of shopping occurencies by costomers
# change the S and NewPriceWeek values in the next command to produce new histograms


library(ggplot2)
library(dplyr)
library(tidyr)

# Step 1: Reshape the data into long format
long_data <- combined_prac %>%
  pivot_longer(
    cols = starts_with("Customer"),  # Select columns Customer_1 to Customer_200
    names_to = "Customer",           # Create a new column for customer names
    values_to = "Day"                # Values indicate the day or No-shopping
  )

# Step 2: Count relative frequencies for each day
relative_frequency_data <- long_data %>%
  group_by(Day) %>%
  summarise(Frequency = n()) %>%              # Absolute frequency
  mutate(RelativeFrequency = Frequency / sum(Frequency)) %>%  # Convert to relative frequencies
  mutate(Day = factor(Day, levels = c(1:7, 8), labels = c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "No-Buy")))

# Step 3: Create a bar chart of the relative frequency distribution
ggplot(relative_frequency_data, aes(x = Day, y = RelativeFrequency)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black", width = 0.5) +  # Create bars
#  geom_text(aes(label = round(RelativeFrequency * 100,1)),  # Round and display integer percentages
#            vjust = -0.5, size = 8) +  # Position above bars
  geom_vline(xintercept = 7.5, linetype = "dashed", color = "red", linewidth = 1) +  # Vertical dashed line
  labs(
    x = "Day of the Week",
    y = "Relative Frequency (%)"
  ) +
  scale_y_continuous(labels = function(x) round(x * 100, 1)) +  # Format y-axis as percentages
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 0.5, size = 21),  # X-axis text size
    axis.text.y = element_text(size = 21),  # Y-axis text size
    axis.title.x = element_text(size = 25),  # X-axis label size and bold , face = "bold"
    axis.title.y = element_text(size = 25)   # Y-axis label size and bold
  )  # Rotate x-axis labels for readability


#########################################################################################
#
#     boxploty pod2a clusterov
#
#########################################################################################

library(ggplot2)

# Create boxplots comparing SellerWeeklyProfits by Cluster
ggplot(clustering_results, aes(x = factor(Cluster), y = SellerWeeklyProfits)) +
  geom_boxplot(fill = "lightblue", color = "black") +  # Boxplot aesthetics
  labs(
    title = "Comparison of Seller Weekly Profits by Cluster",
    x = "Cluster",
    y = "Seller Weekly Profits"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for clarity





##################################################################################################
#
#           rozdelenie pocetnosti  podla clusterov
#
##################################################################################################



library(ggplot2)
library(dplyr)
library(tidyr)

# Step 1: Reshape the data into long format
combined_prac1 <- combined_prac[combined_prac$S==1,]
combined_prac2 <- cbind(combined_prac1,as.numeric(clusters))
colnames(combined_prac2)[214] <- "clusters"
combined_prac3 <- combined_prac2[combined_prac2$clusters==6,]

# s tym budeme dalej pracovat ------>>>>>> combined_prac3
rm(combined_prac1)
rm(combined_prac2)



long_data <- combined_prac3 %>%
  pivot_longer(
    cols = starts_with("Customer"),  # Select columns Customer_1 to Customer_200
    names_to = "Customer",           # Create a new column for customer names
    values_to = "Day"                # Values indicate the day or No-shopping
  )

# Step 2: Count relative frequencies for each day
relative_frequency_data <- long_data %>%
  group_by(Day) %>%
  summarise(Frequency = n()) %>%              # Absolute frequency
  mutate(RelativeFrequency = Frequency / sum(Frequency)) %>%  # Convert to relative frequencies
  mutate(Day = factor(Day, levels = c(1:7, 8), labels = c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "No-Buy")))

# Step 3: Create a bar chart of the relative frequency distribution
ggplot(relative_frequency_data, aes(x = Day, y = RelativeFrequency)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black", width = 0.5) +  # Create bars
  geom_text(aes(label = round(RelativeFrequency * 100,1)),  # Round and display integer percentages
            vjust = -0.5, size = 4) +  # Position above bars
  geom_vline(xintercept = 7.5, linetype = "dashed", color = "red", linewidth = 1) +  # Vertical dashed line
  labs(
    title = "Relative Frequency Distribution of Shopping Days (%)",
    x = "Day of the Week",
    y = "Relative Frequency (%)"
  ) +
  scale_y_continuous(labels = scales::percent) +  # Format y-axis as percentages
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for readability

rm(combined_prac3)





################################################################################
################################################################################
#
#     TESTOVANIE , ci sa seller vo svojej cenovej politike správa racionálne
#
################################################################################



#####   test intuitivnych pravidiel
##################################
ceny <- filtered_data[,7:13]
dni <- filtered_data[,14:213]

all_levels <- c(1, 2, 3, 4, 5,6,7,8)  #indexovanie dni v tyzdni aj nenakupovania
tyzden <- all_levels[-8]              # indexovanie dni v tyzdni 
pocetnost_uspechu_max <- 0
pocetnost_celkovo_max <- 0
pocetnost_uspechu_min <- 0
pocetnost_celkovo_min <- 0
pocetnost_celkovo_nenakupov <- 0
pocetnost_uspechu_nenakupov <- 0
pocetnost_celkovo_nenakupov2 <- 0
pocetnost_uspechu_nenakupov2 <- 0
pocetnost_celkovo_nenakupov_dyn <- 0
pocetnost_uspechu_nenakupov_dyn <- 0

for (i in 1:99){
#  najviac <- which.max(table(as.numeric(dni[i,dni!=8])))
  najmenej <- which.min(table(factor(dni[i,],levels=tyzden))[1:7])
#  for (j in 1:200){
#    if (dni[i,j] == najviac){
#      pocetnost_celkovo_max <- pocetnost_celkovo_max + 1
#      if (ceny[i+1,najviac] >= ceny[i,najviac]){
#        pocetnost_uspechu_min <- pocetnost_uspechu_min + 1
#      }
#      
#    }

      pocetnost_celkovo_min <- pocetnost_celkovo_min + 1
      if (ceny[i+1,najmenej] <= ceny[i,najmenej]){
        pocetnost_uspechu_min <- pocetnost_uspechu_min + 1
      }
}

print(paste("ak je malo nakupov, potom cena klesa","\n"))
print(paste("V pripade maleho poctu nakupovcena narasta v", pocetnost_uspechu_min, "pripadoch zo ",pocetnost_celkovo_min))



######################  ak je vela nakupov, potom cena narasta

for (i in 1:99){
  
  najviac <- which.max(table(factor(dni[i,],levels=tyzden))[1:7])
  #  najmenej <- which.min(table(as.numeric(dni[i,])))
  
  
  pocetnost_celkovo_max <- pocetnost_celkovo_max + 1
  if (ceny[(i+1),najviac] >= ceny[i,najviac]){
    pocetnost_uspechu_max <- pocetnost_uspechu_max + 1
  }
}
print(paste("ak je vela nakupov, potom cena narasta"))
print(paste("pocetnost uspechu max:", pocetnost_uspechu_max,"z celkovo",pocetnost_celkovo_max))


###########  Ak je maximalna frequencia nenakupovania, potom priemerne ceny klesnu v dalsom tyzdni

pocetnost_uspechu_max <- 0
pocetnost_celkovo_max <- 0
pocetnost_uspechu_min <- 0
pocetnost_celkovo_min <- 0
pocetnost_celkovo_nenakupov <- 0
pocetnost_uspechu_nenakupov <- 0
pocetnost_celkovo_nenakupov2 <- 0
pocetnost_uspechu_nenakupov2 <- 0
pocetnost_celkovo_nenakupov_dyn <- 0
pocetnost_uspechu_nenakupov_dyn <- 0


for (i in 1:99){
  #print(table(factor(dni[i,],levels=all_levels)))
  
  najviac <- which.max(table(as.numeric(dni[i,],levels=all_levels)))
  #  najmenej <- which.min(table(as.numeric(dni[i,])))
  if (najviac == 8){
    pocetnost_celkovo_nenakupov <- pocetnost_celkovo_nenakupov + 1
    if (mean(as.numeric(ceny[(i+1),])) <= mean(as.numeric(ceny[(i),]))){
      pocetnost_uspechu_nenakupov <- pocetnost_uspechu_nenakupov + 1
    }
  }
  

}
print(paste("Ak je maximalna frequencia nenakupovania, potom priemerne ceny klesnu v dalsom tyzdni"))
print(paste("pocetnost uspechu max:", pocetnost_uspechu_nenakupov,"z celkovo",pocetnost_celkovo_nenakupov))


###########  Ak je frequencia nenakupovania nie je maximalna, potom priemerne ceny narastu v dalsom tyzdni
pocetnost_uspechu_max <- 0
pocetnost_celkovo_max <- 0
pocetnost_uspechu_min <- 0
pocetnost_celkovo_min <- 0
pocetnost_celkovo_nenakupov <- 0
pocetnost_uspechu_nenakupov <- 0
pocetnost_celkovo_nenakupov2 <- 0
pocetnost_uspechu_nenakupov2 <- 0
pocetnost_celkovo_nenakupov_dyn <- 0
pocetnost_uspechu_nenakupov_dyn <- 0


for (i in 1:99){
  #print(table(factor(dni[i,],levels=all_levels)))
  
  najviac <- which.max(table(as.numeric(dni[i,],levels=all_levels)))
  #  najmenej <- which.min(table(as.numeric(dni[i,])))
  if (najviac != 8){
    pocetnost_celkovo_nenakupov2 <- pocetnost_celkovo_nenakupov2 + 1
    if (mean(as.numeric(ceny[(i+1),])) <= mean(as.numeric(ceny[(i),]))){
      pocetnost_uspechu_nenakupov2 <- pocetnost_uspechu_nenakupov2 + 1
    }
  }
  
  
}

print(paste("Ak je frequencia nenakupovania nie je maximalna, potom priemerne ceny narastu v dalsom tyzdni"))
print(paste("pocetnost uspechu max:", pocetnost_uspechu_nenakupov2,"z celkovo",pocetnost_celkovo_nenakupov2))



###########   Ak narastlo nenakupovanie, potom znizime ceny v priemere
pocetnost_uspechu_max <- 0
pocetnost_celkovo_max <- 0
pocetnost_uspechu_min <- 0
pocetnost_celkovo_min <- 0
pocetnost_celkovo_nenakupov <- 0
pocetnost_uspechu_nenakupov <- 0
pocetnost_celkovo_nenakupov2 <- 0
pocetnost_uspechu_nenakupov2 <- 0
pocetnost_celkovo_nenakupov_dyn <- 0
pocetnost_uspechu_nenakupov_dyn <- 0


for (i in 2:99){
  #print(table(factor(dni[i,],levels=1:8)))
  
  narast_nenakupovania <- table(factor(dni[i,],levels=all_levels))[8]-table(factor(dni[i-1,],levels=all_levels))[8]
  narast_priem_cien <- mean(as.numeric(ceny[i+1,])) - mean(as.numeric(ceny[i,]))

  if ((narast_nenakupovania >= 0 & narast_priem_cien <= 0) | (narast_nenakupovania <= 0 & narast_priem_cien >= 0)){
    pocetnost_uspechu_nenakupov_dyn <- pocetnost_uspechu_nenakupov_dyn + 1
  }
  pocetnost_celkovo_nenakupov_dyn <- pocetnost_celkovo_nenakupov_dyn + 1
}

print(paste("Ak narastlo nenakupovanie, potom znizime ceny v priemere"))
print(paste("pocetnost uspechu cenoveho zvysovania/znizovania:", pocetnost_uspechu_nenakupov_dyn,"z celkovo",pocetnost_celkovo_nenakupov_dyn))

############################################################
#   cistenie pamati

rm(list=c("ceny","closest_row","cluster_representatives","clustering_data","clustering_results","curve_data","dni","hclust_result","latex_table","line_data_s1","long_data","relative_frequency_data","scaled_data"))
rm(list=c("current_cluster","all_levels","centroid","clusters","distance_matrix","distances","i","najmenej","najviac","narast_nenakupovania","narast_priem_cien","NumberOfClust","pocetnost_celkovo_max","pocetnost_celkovo_min","pocetnost_celkovo_nenakupov"))
rm(list=c("pocetnost_celkovo_nenakupov_dyn","pocetnost_celkovo_nenakupov2","pocetnost_uspechu_max","pocetnost_uspechu_min","pocetnost_uspechu_nenakupov","pocetnost_uspechu_nenakupov_dyn","pocetnost_uspechu_nenakupov2"))

