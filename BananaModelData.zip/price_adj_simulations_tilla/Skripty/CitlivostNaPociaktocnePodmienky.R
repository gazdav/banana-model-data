#############################################################################
#
#              h r o m a d n e   s i m u l a c i e
#
##############################################################################
#
#
#
#   dataframy su
#              
#                     1 filtered_data1   hromadna - 40 simulacii s meniacimi sa P  stalymi alpha
#                     2 filtered_data2  hromadna - 40 simulacii so stalymi P aj alpha        od riadku 250
#                     3 filtered_data3  hromadna - 40 simulacii - stale P a meniacimi sa alfami    od riadku 500
#
#

#########################################################################
#    n a d c i t a v a n i e   suborov
#                    vysledkom je combined_weekly_data_summary.csv
#                         ktory ma nasledovne stlpce
#"S","NewPriceWeek","SellerWeeklyProfits","SellerSurplus","WeeklyTotalProductSold","WeeklyCustomerSavings",
#"DAY_1","DAY_2","DAY_3","DAY_4","DAY_5","DAY_6","DAY_7","Customer_1","Customer_2",...
########################################################################################




# Source with a local environment
# Clear environment
rm(list = ls())
cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla")


# List all CSV files
csv_files <- list.files(pattern = "weekly_data_summary_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne <- rbind(konecne, temp_data)
  }
}

######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be, 
# if the column will be located as the first in the data.frame
#####################################################

# Add the new column "S" with a default value (e.g., NA or any value)
konecne$S <- NA  # Replace NA with a specific value if needed

# Move "S" to the first position
konecne <- konecne[, c("S", setdiff(names(konecne), "S"))]
konecne$S <- ceiling(seq_len(nrow(konecne)) / 100)

################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyMostChoosenDayPerCustomer_imulation_1.csv
#    - > do dataframe konecny2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla2")

# List all CSV files
csv_files <- list.files(pattern = "weeklyMostChoosenDayPerCustomer_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne2 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne2 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne2)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne2))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne2 <- rbind(konecne2, temp_data)
  }
}


################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyPrice_simulation_i.csv
#    - > do dataframe konecne2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla2")

# List all CSV files
csv_files <- list.files(pattern = "weeklyPrice_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne3 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne3 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne3)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne3))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne3  <- rbind(konecne3, temp_data)
  }
}




#########################################
#  vlozenie vsetkeho do jedneho suboru
#########################################

# Combine the data frames column-wise
combined <- cbind(konecne, konecne3, konecne2)
combined$SellerWeeklyProfits  <- as.numeric(combined$SellerWeeklyProfits)+3000
#combined$SellerWeeklyProfits[-1]  <- as.numeric(combined$SellerWeeklyProfits)[-1]+3000
# Loop through indices 1 to 1200
for (i in 1:4000) {
  if (i %% 100 == 1) {
    combined$SellerWeeklyProfits[i]  <- as.numeric(combined$SellerWeeklyProfits)[i]-3000
  }
}



# Inspect the result
head(combined)

############################################
#konverzia na ciselny tvar dat
combined_prac <- combined

for (i in 1:dim(combined_prac)[2]){
  combined_prac[,i] <- as.numeric(combined_prac[,i])
}

############################################
# Sorting the dataframe by "NewPriceWeek" (primary key) and "S" (secondary key)
combined_prac <- combined_prac %>%
  arrange(S,NewPriceWeek)

# Filter data to include only NewPriceWeek values from 1 to n
filtered_data <- combined_prac %>%
  filter(NewPriceWeek %in% 1:30)

filtered_data1 <- filtered_data
rm(filtered_data)



########################################################
# Save the combined data to a CSV file
#write.csv(combined, "combined_weekly_data_summary.csv", row.names = FALSE)


#################################################
#  mazanie pracovnych premenn7ch a tabuliek

rm(konecne)
rm(konecne2)
rm(konecne3)
rm(i)
rm(temp_data)

































#########################################################################
#    n a d c i t a v a n i e   suborov
#                    vysledkom je combined_weekly_data_summary.csv
#                         ktory ma nasledovne stlpce
#"S","NewPriceWeek","SellerWeeklyProfits","SellerSurplus","WeeklyTotalProductSold","WeeklyCustomerSavings",
#"DAY_1","DAY_2","DAY_3","DAY_4","DAY_5","DAY_6","DAY_7","Customer_1","Customer_2",...
########################################################################################




# Source with a local environment
# Clear environment

cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla2")


# List all CSV files
csv_files <- list.files(pattern = "weekly_data_summary_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne <- rbind(konecne, temp_data)
  }
}

######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be, 
# if the column will be located as the first in the data.frame
#####################################################

# Add the new column "S" with a default value (e.g., NA or any value)
konecne$S <- NA  # Replace NA with a specific value if needed

# Move "S" to the first position
konecne <- konecne[, c("S", setdiff(names(konecne), "S"))]
konecne$S <- ceiling(seq_len(nrow(konecne)) / 30)

################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyMostChoosenDayPerCustomer_imulation_1.csv
#    - > do dataframe konecny2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla2")

# List all CSV files
csv_files <- list.files(pattern = "weeklyMostChoosenDayPerCustomer_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne2 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne2 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne2)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne2))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne2 <- rbind(konecne2, temp_data)
  }
}


################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyPrice_simulation_i.csv
#    - > do dataframe konecne2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla2")

# List all CSV files
csv_files <- list.files(pattern = "weeklyPrice_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne3 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne3 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne3)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne3))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne3  <- rbind(konecne3, temp_data)
  }
}




#########################################
#  vlozenie vsetkeho do jedneho suboru
#########################################

# Combine the data frames column-wise
combined <- cbind(konecne, konecne3, konecne2)
combined$SellerWeeklyProfits  <- as.numeric(combined$SellerWeeklyProfits)

# Inspect the result
head(combined)

############################################
#konverzia na ciselny tvar dat
combined_prac <- combined

for (i in 1:dim(combined_prac)[2]){
  combined_prac[,i] <- as.numeric(combined_prac[,i])
}

############################################
# Sorting the dataframe by "NewPriceWeek" (primary key) and "S" (secondary key)
combined_prac <- combined_prac %>%
  arrange(S,NewPriceWeek)

# Filter data to include only NewPriceWeek values from 1 to n
filtered_data <- combined_prac %>%
  filter(NewPriceWeek %in% 1:30)

filtered_data2 <- filtered_data
rm(filtered_data)



########################################################
# Save the combined data to a CSV file
#write.csv(combined, "combined_weekly_data_summary.csv", row.names = FALSE)


#################################################
#  mazanie pracovnych premenn7ch a tabuliek

rm(konecne)
rm(konecne2)
rm(konecne3)
rm(i)
rm(temp_data)


















































#########################################################
#   teraz to iste ale so sobormi s meniacimi sa alfami  #
#########################################################

# Source with a local environment
# Clear environment

cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla3")


# List all CSV files
csv_files <- list.files(pattern = "weekly_data_summary_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne <- rbind(konecne, temp_data)
  }
}

######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be, 
# if the column will be located as the first in the data.frame
#####################################################

# Add the new column "S" with a default value (e.g., NA or any value)
konecne$S <- NA  # Replace NA with a specific value if needed

# Move "S" to the first position
konecne <- konecne[, c("S", setdiff(names(konecne), "S"))]
konecne$S <- ceiling(seq_len(nrow(konecne)) / 30)

################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyMostChoosenDayPerCustomer_imulation_1.csv
#    - > do dataframe konecny2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla2")

# List all CSV files
csv_files <- list.files(pattern = "weeklyMostChoosenDayPerCustomer_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne2 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne2 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne2)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne2))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne2 <- rbind(konecne2, temp_data)
  }
}


################################################################################
#################################################################################
#     
# teraz pridavame transferujeme nove subory
#                    weeklyPrice_simulation_i.csv
#    - > do dataframe konecne2
#
################################################################################

# Clear environment

cat("\014")

# Set working directory
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla2")

# List all CSV files
csv_files <- list.files(pattern = "weeklyPrice_simulation_\\d+\\.csv")

# Initialize an empty data frame for combining data
konecne3 <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne3 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne3)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne3))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne3  <- rbind(konecne3, temp_data)
  }
}




#########################################
#  vlozenie vsetkeho do jedneho suboru
#########################################

# Combine the data frames column-wise
combined <- cbind(konecne, konecne3, konecne2)
combined$SellerWeeklyProfits  <- as.numeric(combined$SellerWeeklyProfits)

# Inspect the result
head(combined)

############################################
#konverzia na ciselny tvar dat
combined_prac <- combined

for (i in 1:dim(combined_prac)[2]){
  combined_prac[,i] <- as.numeric(combined_prac[,i])
}

############################################
# Sorting the dataframe by "NewPriceWeek" (primary key) and "S" (secondary key)
combined_prac <- combined_prac %>%
  arrange(S,NewPriceWeek)

# Filter data to include only NewPriceWeek values from 1 to n
filtered_data <- combined_prac %>%
  filter(NewPriceWeek %in% 1:30)

filtered_data3 <- filtered_data
rm(filtered_data)



########################################################
# Save the combined data to a CSV file
#write.csv(combined, "combined_weekly_data_summary.csv", row.names = FALSE)


#################################################
#  mazanie pracovnych premenn7ch a tabuliek

rm(konecne)
rm(konecne2)
rm(konecne3)
rm(i)
rm(temp_data)







# Uprava filetered.datai do jedneho na to, aby sme robili boxploty
#             vytvorime osobitne vektory a dame ich do 1 data.framu aby sme mohli robit graf

WeeklyTotalProductSold2  <- filtered_data1$WeeklyTotalProductSold
WeeklyTotalProductSold1  <- filtered_data2$WeeklyTotalProductSold
WeeklyTotalProductSold3  <- filtered_data3$WeeklyTotalProductSold

SellerWeeklyProfits2 <- filtered_data1$SellerWeeklyProfits
SellerWeeklyProfits1 <- filtered_data2$SellerWeeklyProfits
SellerWeeklyProfits3 <- filtered_data3$SellerWeeklyProfits

S <- filtered_data1$S
NewPriceWeek <- filtered_data1$NewPriceWeek

#   teraz teda spolocna databaza

# Create the data frame
udaje <- data.frame(
  S = S,
  NewPriceWeek = NewPriceWeek,
  WeeklyTotalProductSold1 = WeeklyTotalProductSold1,
  WeeklyTotalProductSold2 = WeeklyTotalProductSold2,
  WeeklyTotalProductSold3 = WeeklyTotalProductSold3,
  SellerWeeklyProfits1 = SellerWeeklyProfits1,
  SellerWeeklyProfits2 = SellerWeeklyProfits2,
  SellerWeeklyProfits3 = SellerWeeklyProfits3
)

# Print the data frame
#head(udaje)

############################################
# Sorting the dataframe by "NewPriceWeek" (primary key) and "S" (secondary key)
udaje <- udaje %>%
  arrange(S,NewPriceWeek)
head(udaje)

#   vyber niekolkych prvych kol

# Filter data to include only NewPriceWeek values from 1 to n
udaje <- udaje %>%
  filter(NewPriceWeek %in% 1:25)


###############################################################################
# 
#          vytvorime obrazok   z predanych tovarov
#



library(ggplot2)
library(dplyr)

# Reshape the data for proper grouping (no need for a long format)
udaje_long <- udaje %>%
  pivot_longer(
    cols = starts_with("WeeklyTotalProductSold"),  # Select the relevant columns
    names_to = "Group",                            # Create a new column for group names
    values_to = "Value"                            # Create a new column for the values
  )

# Create grouped boxplots with the legend below the plot
ggplot(udaje_long, aes(x = factor(NewPriceWeek), y = Value, fill = Group)) +
  geom_boxplot(position = position_dodge(width = 0.8), color = "black", width = 0.6) +
  scale_fill_manual(values = c("WeeklyTotalProductSold1" = "white", 
                               "WeeklyTotalProductSold2" = "lightgrey",
                               "WeeklyTotalProductSold3" = "darkgrey"), 
labels = c("Text1", "Text2", "Text3")  # Custom labels for the legend
) +
  labs(
    title = "Grouped Boxplots of Weekly Total Products Sold by NewPriceWeek",
    x = "Week",
    y = "Weekly Total Products Sold"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels
    legend.title = element_blank(),                    # Remove legend title
    legend.position = "bottom",                        # Move legend below the plot
    legend.direction = "horizontal",                    # Arrange legend items horizontally
    legend.text = element_text(size = 14)         # Increase legend text size
)

###############################################################################
# 
#          vytvorime obrazok   z revenues
#



library(ggplot2)
library(dplyr)

# Reshape the data for proper grouping (no need for a long format)
udaje_long <- udaje %>%
  pivot_longer(
    cols = starts_with("SellerWeeklyProfits"),  # Select the relevant columns
    names_to = "Group",                            # Create a new column for group names
    values_to = "Value"                            # Create a new column for the values
  )

# Create grouped boxplots with the legend below the plot
ggplot(udaje_long, aes(x = factor(NewPriceWeek), y = Value, fill = Group)) +
  geom_boxplot(position = position_dodge(width = 0.8), color = "black", width = 0.6) +
  scale_fill_manual(values = c("SellerWeeklyProfits1" = "white", 
                               "SellerWeeklyProfits2" = "lightgrey",
                               "SellerWeeklyProfits3" = "darkgrey"), 
                    labels = c("No variations", "Varying initial prices", "Varying Consumer population")  # Custom labels for the legend
  ) +
  labs(
    x = "Week",
    y = "Revenues",
    fill = NULL  # Removes legend title ("Group")
  ) +
  scale_y_continuous(labels = function(x) ifelse(x >= 1000, paste0(x / 1000, "K"), x)) +  # Convert 5000 to 5K, 10000 to 10K
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1, size = 10),  # X-axis text size
    axis.text.y = element_text(size = 10),  # Y-axis text size
    axis.title.x = element_text(size = 15),  # X-axis label size
    axis.title.y = element_text(size = 15),  # Y-axis label size
    legend.position = "bottom",  # Move legend below the figure
    legend.text = element_text(size = 14),  # Increase legend text size
    legend.title = element_blank()  # Remove "Group" from legend
  )  
