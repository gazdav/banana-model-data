#############################################################################
#
#             SCALE INVARIANCE   h r o m a d n e   s i m u l a c i e
#
##############################################################################
#
#
#
#   dataframy su
#              
#                     1 filtered_data1   hromadna - 40 simulacii s meniacimi sa P  stalymi alpha
#                     2 filtered_data2  hromadna - 40 simulacii so stalymi P aj alpha        od riadku 250
#                     3 filtered_data3  hromadna - 40 simulacii - stale P a meniacimi sa alfami    od riadku 500
#
#

#########################################################################
#    n a d c i t a v a n i e   suborov
#                    vysledkom je combined_weekly_data_summary.csv
#                         ktory ma nasledovne stlpce
#"S","NewPriceWeek","SellerWeeklyProfits","SellerSurplus","WeeklyTotalProductSold","WeeklyCustomerSavings",
#"DAY_1","DAY_2","DAY_3","DAY_4","DAY_5","DAY_6","DAY_7","Customer_1","Customer_2",...
########################################################################################




# Source with a local environment
# Clear environment
rm(list = ls())
cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/ScaleInvariance")


# List all CSV files

#csv_files <- list.files(path = ".", pattern = "^weekly_data.*\\.csv$", full.names = FALSE)
csv_files <- list.files(path = ".", pattern = "^weekly_data_customers_100_.*\\.csv$", full.names = FALSE)



# Initialize an empty data frame for combining data
konecne <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne <- rbind(konecne, temp_data)
  }
}

#normovanie udajov
konecne$RevenuesPerCustomer <- as.numeric(konecne$SellerWeeklyProfits) / 100



######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be, 
# if the column will be located as the first in the data.frame
#####################################################

# Add the new column "S" with a default value (e.g., NA or any value)
konecne$S <- NA  # Replace NA with a specific value if needed

# Move "S" to the first position
konecne <- konecne[, c("S", setdiff(names(konecne), "S"))]
konecne$S <- ceiling(seq_len(nrow(konecne)) / 25)










# Teraz analyzaa pre 200 spotrebitelov

# List all CSV files

rm(csv_files)
csv_files <- list.files(path = ".", pattern = "^weekly_data_customers_200_.*\\.csv$", full.names = FALSE)


# Initialize an empty data frame for combining data
konecne2 <- NULL
rm(temp_data)

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne2 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne2)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne2))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne2 <- rbind(konecne2, temp_data)
  }
}

#normovanie udajov
konecne2$RevenuesPerCustomer <- as.numeric(konecne2$SellerWeeklyProfits) / 200

######################################################
#add one column of called "S" to my konecne data.frame. The best solution would be, 

# Add the new column "S" with a default value (e.g., NA or any value)
konecne2$S <- NA  # Replace NA with a specific value if needed

# Move "S" to the first position
konecne2 <- konecne2[, c("S", setdiff(names(konecne2), "S"))]
konecne2$S <- ceiling(seq_len(nrow(konecne2)) / 25)






# Teraz analyzaa pre 400 spotrebitelov

# List all CSV files

csv_files <- list.files(path = ".", pattern = "^weekly_data_customers_400_.*\\.csv$", full.names = FALSE)


# Initialize an empty data frame for combining data
konecne3 <- NULL
rm(temp_data)

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne3 <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne3)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne3))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne3 <- rbind(konecne3, temp_data)
  }
}

#normovanie udajov
konecne3$RevenuesPerCustomer <- as.numeric(konecne3$SellerWeeklyProfits) / 400

######################################################
#add one column of called "S" to my konecne3 data.frame. The best solution would be, 

# Add the new column "S" with a default value (e.g., NA or any value)
konecne3$S <- NA  # Replace NA with a specific value if needed

# Move "S" to the first position
konecne3 <- konecne3[, c("S", setdiff(names(konecne3), "S"))]
konecne3$S <- ceiling(seq_len(nrow(konecne3)) / 25)






########################################################
#
#    v y t v o r e n i e   z a v e r e c n e h o    suboru
#
#########################################################


konecne_final <- data.frame(cbind(konecne$S,konecne$NewPriceWeek,konecne$RevenuesPerCustomer,konecne2$RevenuesPerCustomer,konecne3$RevenuesPerCustomer))
colnames(konecne_final)<-c("S","Week","RevenuesPerCustomer100","RevenuesPerCustomer200","RevenuesPerCustomer400")
konecne_final$S<- as.numeric(konecne_final$S)
konecne_final$Week<- as.numeric(konecne_final$Week)
konecne_final$RevenuesPerCustomer100<- as.numeric(konecne_final$RevenuesPerCustomer100)
konecne_final$RevenuesPerCustomer200<- as.numeric(konecne_final$RevenuesPerCustomer200)
konecne_final$RevenuesPerCustomer400<- as.numeric(konecne_final$RevenuesPerCustomer400)

#################################################
#  mazanie pracovnych premenn7ch a tabuliek

rm(konecne)
rm(konecne2)
rm(konecne3)
rm(i)
rm(temp_data)





































##########################################################################
#
#             R O B E N I E   O B R A Z K O V
#
##########################################################################



############################################
# Sorting the dataframe by "Week" (primary key) and "S" (secondary key)
combined_prac <- konecne_final %>%
  arrange(S,Week)



####################################################

df <- data.frame(S=combined_prac$S,
  Week = combined_prac$Week,
  RevenuesPerCustomer100 = combined_prac$RevenuesPerCustomer100,
  RevenuesPerCustomer200 = combined_prac$RevenuesPerCustomer200,
  RevenuesPerCustomer400 = combined_prac$RevenuesPerCustomer400
)

# Reshape the data for ggplot
df_long <- df %>%
  pivot_longer(
    cols = starts_with("RevenuesPerCustomer"),  
    names_to = "CustomerGroup",  
    values_to = "Revenue"  
  )

# Define colors similar to reference plot
custom_colors <- c("RevenuesPerCustomer100" = "white",
                   "RevenuesPerCustomer200" = "lightgrey",
                   "RevenuesPerCustomer400" = "darkgrey")

# Create the boxplot
ggplot(df_long, aes(x = factor(Week), y = Revenue, fill = CustomerGroup)) +
  geom_boxplot(position = position_dodge(width = 0.8), color = "black", width = 0.6) +
  scale_fill_manual(values = custom_colors, 
                    labels = c("100 Consumers", "200 Consumers", "400 Consumers")) +  
  labs(
    x = "Week",
    y = "Revenues per Customer",
    fill = NULL  # Removes legend title
  ) +
  scale_y_continuous(labels = function(x) ifelse(x >= 1000, paste0(x / 1000, "K"), x)) +  
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1, size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 15),
    axis.title.y = element_text(size = 15),
    legend.position = "bottom",
    legend.text = element_text(size = 12),
    legend.title = element_blank()
  )