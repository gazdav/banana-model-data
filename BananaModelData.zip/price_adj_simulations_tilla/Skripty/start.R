# Main.R


setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla/Skripty")
try(source("ScriptNadcitavanieSuborov.R", local = TRUE))
#
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla/Skripty")
try(source("PilotStatAnalyzy.R", local = TRUE))
#
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla/Skripty")
try(source("HromadneStatAnalyzy.R", local = TRUE))
#
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla/Skripty")
try(source("HromadneStatAnalyzy.R", local = TRUE))
#