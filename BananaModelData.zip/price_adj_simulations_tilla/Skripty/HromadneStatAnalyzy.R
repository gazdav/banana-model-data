

# Source with a local environment
# nadcitavanie suborov csv a ich prevod do data.frame nazvaneho "combined"
#setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/price_adj_simulations_tilla/Skripty")
#source("ScriptNadcitavanieSuborov.R", local = TRUE)


# udaje su nadcitane 


#####################################################################
#
#              prva rozsiahla analyza - vypoctova stabilita (convergencia)
# budeme riesi5 len prvych 20 kol simulacie


# vytvaram pracovny subor combined, pretože do neho budem robiť zásahy, na 
# zaciatku to prekonvertujem do ciselneho formatu

#combined_prac <- combined

#for (i in 1:dim(combined_prac)[2]){
#  combined_prac[,i] <- as.numeric(combined_prac[,i])
#}

################# L I B R A R I E S    #########################
library(ggplot2)
library(dplyr)
library(tidyr)
library(moments)  # For skewness and kurtosis
library(xtable) 
library(dendextend)
library(reshape)
















#############################################################
#
#            P r i p r a v a   u d a j o v
#
############################################################



# Sorting the dataframe by "NewPriceWeek" (primary key) and "S" (secondary key)
combined_prac <- combined_prac %>%
  arrange(NewPriceWeek, S)

# Filter data to include only NewPriceWeek values from 1 to n
#filtered_data <- combined_prac %>%
#  filter(NewPriceWeek %in% 1:100) %>%
#  filter(S==1)




###########################################################
#
#   H r o m a d n e   simulacie
#
# vytriedenie suboru combined_prac a jeho filtracia
#
###########################################################
print(paste("ideme robit druhy obrazok"))

# Sorting the dataframe by "NewPriceWeek" (primary key) and "S" (secondary key)
combined_prac <- combined_prac %>%
  arrange(NewPriceWeek, S)

# Filter data to include only NewPriceWeek values from 1 to n
filtered_data <- combined_prac %>%
  filter(NewPriceWeek %in% 1:50)
############################################################


#######   obrazok o predanych kusoch

# a figure with n boxplots, each for a unique NewPriceWeek, changing from 1 to ...


# Calculate the 1st quartile (Q1), median, and 3rd quartile (Q3) of WeeklyTotalProductSold for each NewPriceWeek
# Cervena ciara je objem predaja z 6tej simulacie
quartile_data <- filtered_data %>%
  group_by(NewPriceWeek) %>%
  summarize(
    Q1 = quantile(WeeklyTotalProductSold, 0.25, na.rm = TRUE),
    MedianValue = median(WeeklyTotalProductSold, na.rm = TRUE),
    Q3 = quantile(WeeklyTotalProductSold, 0.65, na.rm = TRUE)
  )

# Generate smoothed splines for Q1, median, and Q3
smooth_spline_q1 <- smooth.spline(x = quartile_data$NewPriceWeek, y = quartile_data$Q1, spar = 0.45)
smooth_spline_median <- smooth.spline(x = quartile_data$NewPriceWeek, y = quartile_data$MedianValue, spar = 0.45)
smooth_spline_q3 <- smooth.spline(x = quartile_data$NewPriceWeek, y = quartile_data$Q3, spar = 0.45)

# Extract x and y values for each spline and convert to data frames
spline_data_q1 <- data.frame(NewPriceWeek = smooth_spline_q1$x, SmoothedQ1 = smooth_spline_q1$y)
spline_data_median <- data.frame(NewPriceWeek = smooth_spline_median$x, SmoothedMedian = smooth_spline_median$y)
spline_data_q3 <- data.frame(NewPriceWeek = smooth_spline_q3$x, SmoothedQ3 = smooth_spline_q3$y)



# Filter data for S == 6 and S == 5
line_data_s1 <- filtered_data %>%
  filter(S == 6) %>%
  group_by(NewPriceWeek) %>%
  summarize(WeeklyTotalProductSold = mean(WeeklyTotalProductSold, na.rm = TRUE))

#line_data_s5 <- filtered_data %>%
#  filter(S == 5) %>%
#  group_by(NewPriceWeek) %>%
#  summarize(SellerWeeklyProfits = mean(SellerWeeklyProfits, na.rm = TRUE))

# Create the boxplots with the smoothed spline curves and added lines
ggplot(data = filtered_data, aes(x = factor(NewPriceWeek), y = WeeklyTotalProductSold)) +
  geom_boxplot(fill = "lightgrey") +
  # Add smoothed curves for Q1, median, and Q3
  geom_line(data = spline_data_q1, aes(x = NewPriceWeek, y = SmoothedQ1, group = 1),
            color = "black", linetype = "dashed", linewidth = 0.5) +  # Smoothed Q1
  geom_line(data = spline_data_median, aes(x = NewPriceWeek, y = SmoothedMedian, group = 1),
            color = "black", linewidth = 0.5) +  # Smoothed Median
  geom_line(data = spline_data_q3, aes(x = NewPriceWeek, y = SmoothedQ3, group = 1),
            color = "black", linetype = "dashed", linewidth = 0.5) +  # Smoothed Q3
  # Add red line for S == 6
  geom_line(data = line_data_s1, aes(x = NewPriceWeek, y = WeeklyTotalProductSold, group = 1),
            color="red", linewidth = 0.6) +
  # Add blue line for S == 5
  # geom_line(data = line_data_s5, aes(x = NewPriceWeek, y = SellerWeeklyProfits, group = 1),
  #          color = "blue", linewidth = 0.6) +
  labs(
    title = "Boxplots of WeeklyTotalProductSold with Smoothed Quartile Curves and S Lines",
    x = "NewPriceWeek",
    y = "WeeklyTotalProductSold"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for readability


##################### thE same with SellerWeeklyProfits
#######   obrazok o revenues

# a figure with n boxplots, each for a unique NewPriceWeek, changing from 1 to ...


# Calculate the 1st quartile (Q1), median, and 3rd quartile (Q3) of SellerWeeklyProfits for each NewPriceWeek
# Cervena ciara je objem predaja z 6tej simulacie
quartile_data <- filtered_data %>%
  group_by(NewPriceWeek) %>%
  summarize(
    Q1 = quantile(SellerWeeklyProfits, 0.25, na.rm = TRUE),
    MedianValue = median(SellerWeeklyProfits, na.rm = TRUE),
    Q3 = quantile(SellerWeeklyProfits, 0.65, na.rm = TRUE)
  )

# Generate smoothed splines for Q1, median, and Q3
smooth_spline_q1 <- smooth.spline(x = quartile_data$NewPriceWeek, y = quartile_data$Q1, spar = 0.45)
smooth_spline_median <- smooth.spline(x = quartile_data$NewPriceWeek, y = quartile_data$MedianValue, spar = 0.45)
smooth_spline_q3 <- smooth.spline(x = quartile_data$NewPriceWeek, y = quartile_data$Q3, spar = 0.45)

# Extract x and y values for each spline and convert to data frames
spline_data_q1 <- data.frame(NewPriceWeek = smooth_spline_q1$x, SmoothedQ1 = smooth_spline_q1$y)
spline_data_median <- data.frame(NewPriceWeek = smooth_spline_median$x, SmoothedMedian = smooth_spline_median$y)
spline_data_q3 <- data.frame(NewPriceWeek = smooth_spline_q3$x, SmoothedQ3 = smooth_spline_q3$y)



# Filter data for S == 6 and S == 5
line_data_s1 <- filtered_data %>%
  filter(S == 6) %>%
  group_by(NewPriceWeek) %>%
  summarize(SellerWeeklyProfits = mean(SellerWeeklyProfits, na.rm = TRUE))

#line_data_s5 <- filtered_data %>%
#  filter(S == 5) %>%
#  group_by(NewPriceWeek) %>%
#  summarize(SellerWeeklyProfits = mean(SellerWeeklyProfits, na.rm = TRUE))

# Create the boxplots with the smoothed spline curves and added lines
ggplot(data = filtered_data, aes(x = factor(NewPriceWeek), y = SellerWeeklyProfits)) +
  geom_boxplot(fill = "lightgrey") +
  # Add smoothed curves for Q1, median, and Q3
  geom_line(data = spline_data_q1, aes(x = NewPriceWeek, y = SmoothedQ1, group = 1),
            color = "black", linetype = "dashed", linewidth = 0.5) +  # Smoothed Q1
  geom_line(data = spline_data_median, aes(x = NewPriceWeek, y = SmoothedMedian, group = 1),
            color = "black", linewidth = 0.5) +  # Smoothed Median
  geom_line(data = spline_data_q3, aes(x = NewPriceWeek, y = SmoothedQ3, group = 1),
            color = "black", linetype = "dashed", linewidth = 0.5) +  # Smoothed Q3
  # Add red line for S == 6
  geom_line(data = line_data_s1, aes(x = NewPriceWeek, y = SellerWeeklyProfits, group = 1),
            color="red", linewidth = 0.6) +
  # Add blue line for S == 5
  # geom_line(data = line_data_s5, aes(x = NewPriceWeek, y = SellerWeeklyProfits, group = 1),
  #          color = "blue", linewidth = 0.6) +
  labs(
    title = "Boxplots of SellerWeeklyProfits with Smoothed Quartile Curves and S Lines",
    x = "NewPriceWeek",
    y = "SellerWeeklyProfits"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for readability


print(paste("dalsi obrazok"))




#########################################################################################
#
# r o z d e l e n i e   p o c e t n o s t i   kedy sa nakupuje
#
#########################################################################################

############################################
#konverzia na ciselny tvar dat
#combined_prac <- combined

##for (i in 1:dim(combined_prac)[2]){
#  combined_prac[,i] <- as.numeric(combined_prac[,i])
#}

############################################

# H I S T O G R A M   of the day of shopping occurencies by costomers
# change the S and NewPriceWeek values in the next command to produce new histograms





# Create a vector of your data (last 200 numbers)
data_vector <- as.vector(combined_prac[combined_prac$S==1 & combined_prac$NewPriceWeek==20, 14:213])
data_vector<- unlist(data_vector)

# Convert the data into a data frame
data_df <- data.frame(
  Day = factor(data_vector, levels = 1:8, labels = c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "NoBuy"))
)

# Create the histogram of frequencies
ggplot(data_df, aes(x = Day)) +
  geom_bar(fill = "lightgrey", color = "black", width = 0.6) +  # Light grey bars with black borders
  labs(
    title = "Histogram of Shopping Days (Mon - Sun) and No-Buy Strategy (S==2 & NewPriceWeek==2)",
    x = "Day of the Week / NoBuy",
    y = "Frequency"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for readability


rm(list=ls())
























