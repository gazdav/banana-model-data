#############################################################################
#
#              h r o m a d n e   s i m u l a c i e - parameters sensitivity
#


#########################################################################
#    n a d c i t a v a n i e   suborov
#                    vysledkom je combined_weekly_data_summary.csv
#                         ktory ma nasledovne stlpce
#"S","NewPriceWeek","SellerWeeklyProfits","SellerSurplus","WeeklyTotalProductSold","WeeklyCustomerSavings",
########################################################################################



#########################################################################
#    n a d c i t a v a n i e   suborov
#                    vysledkom je combined_weekly_data_summary.csv
#                         ktory ma nasledovne stlpce
# zoradene podla tachometer ako je naznacene nizsie
########################################################################################





# Source with a local environment
# Clear environment
rm(list = ls())
cat("\014")

# Set working directory
setwd("/cloud/project/DynamickeCeny/cluster_analysis/udaje_tilla/ParametersSensitivity")


# List all CSV files

#csv_files <- list.files(path = ".", pattern = "^weekly_data.*\\.csv$", full.names = FALSE)
csv_files <- list.files(path = ".", pattern = "^weekly_data.*\\.csv$", full.names = FALSE)



# Initialize an empty data frame for combining data
konecne <- NULL

# Iterate through files and combine
for (i in seq_along(csv_files)) {
  if (i == 1) {
    # Read the first file with headers
    temp_data <- read.csv(csv_files[i], header = TRUE)
    konecne <- temp_data
  } else {
    # Read subsequent files without headers
    temp_data <- read.csv(csv_files[i], header = FALSE)
    
    # Ensure column names match the first file
    colnames(temp_data) <- colnames(konecne)
    
    # Exclude rows that match the header row of the first file
    if (all(temp_data[1, ] == colnames(konecne))) {
      temp_data <- temp_data[-1, ]
    }
    
    # Append to the combined data frame
    konecne <- rbind(konecne, temp_data)
  }
}


#  nejakov v cykle vygenerujem prislusne NewPriceWeek 1:8; S 1:4; rho 0.2, 0.4, 0.6, 0.8; M 80,100,120,140
# v hlbke vnorenia
#     1. rho
#     2. M
#     3. S
#     4. NewPriceWeek
vect_rho <- rep(0,times=448)
vect_M <- rep(0,times=448)
vect_S <- rep(0,times=448)
vect_SumarnyIndex <- rep(0,times=448)


SumarnyIndex <- 1
for (rho in c(0.2,0.4,0.6,0.8)){
  for (M in c(100,120,140,80)){
    for (S in 1:4){
      for (index in 1:8) {
        if (!( (rho == 0.8 & M == 120) | (rho == 0.8 & M == 140) )) {
          vect_rho[SumarnyIndex] <- rho
          vect_M[SumarnyIndex] <- M
          vect_S[SumarnyIndex] <- S
          vect_SumarnyIndex[SumarnyIndex] <- SumarnyIndex
          SumarnyIndex <- SumarnyIndex+1
        }
      }
    }
  }
}


konecne$NewPriceWeek <- as.numeric(konecne$NewPriceWeek)
konecne$SellerWeeklyProfits <- as.numeric(konecne$SellerWeeklyProfits)
konecne$SellerSurplus <- as.numeric(konecne$SellerSurplus)
konecne$WeeklyTotalProductSold <- as.numeric(konecne$WeeklyTotalProductSold)
konecne$WeeklyCustomerSavings <- as.numeric(konecne$WeeklyCustomerSavings)

vect_rho <-  as.numeric(vect_rho)
vect_M <- as.numeric(vect_M)
vect_S <- as.numeric(vect_S) 
vect_SumarnyIndex <- as.numeric(vect_SumarnyIndex)




udaje <- data.frame(cbind(konecne$NewPriceWeek,konecne$SellerWeeklyProfits,konecne$SellerSurplus,konecne$WeeklyTotalProductSold,konecne$WeeklyCustomerSavings,vect_rho, vect_M, vect_S, vect_SumarnyIndex))
colnames(udaje) <- c("NewPriceWeek","SellerWeeklyProfits","SellerSurplus","WeeklyTotalProductSold","WeeklyCustomerSavings","rho","M","S","SumarnyIndex")
udaje <- udaje[udaje$NewPriceWeek != 1, ]   # vylucenie prvych kol


rm(vect_rho,vect_M,vect_S,vect_SumarnyIndex,SumarnyIndex,i,index,M,rho,S)



##############################################################
# 
# Teraz regresia  - T R Z B Y REVENUES
#
##############################################################

attach(udaje)
regresia_vysledok <- lm(SellerWeeklyProfits~+1+M+rho,data = udaje)
latex_table <- xtable(summary(regresia_vysledok), caption = "Seller's Revenues vs. M and Rho")

# Print LaTeX code in the console
#print(latex_table, include.rownames = FALSE, caption.placement = "top")

# Optionally export to a .tex file
write(print(latex_table, include.rownames = FALSE, caption.placement = "top"), 
      file = "summary_statistics.tex")
rm(latex_table)

##############################################################
# 
# Teraz regresia  - T R Z B Y sURPLUS
#
##############################################################

#attach(udaje)
regresia_vysledok <- lm(SellerSurplus~+1+M+rho,data = udaje)
latex_table <- xtable(summary(regresia_vysledok), caption = "Seller's surplus vs. M and Rho")

# Print LaTeX code in the console
#print(latex_table, include.rownames = FALSE, caption.placement = "top")

# Optionally export to a .tex file
write(print(latex_table, include.rownames = FALSE, caption.placement = "top"), 
      file = "summary_statistics.tex")
rm(latex_table)


##############################################################
# 
# Teraz regresia  - predane kusy
#
##############################################################

#attach(udaje)
regresia_vysledok <- lm(WeeklyTotalProductSold~+1+M+rho,data = udaje)
latex_table <- xtable(summary(regresia_vysledok), caption = "Seller's WeeklyTotalProductSold vs. M and Rho")

# Print LaTeX code in the console
#print(latex_table, include.rownames = FALSE, caption.placement = "top")

# Optionally export to a .tex file
write(print(latex_table, include.rownames = FALSE, caption.placement = "top"), 
      file = "summary_statistics.tex")
rm(latex_table)

##############################################################
# 
# Teraz regresia  - Customers savings
#
##############################################################

#attach(udaje)
regresia_vysledok <- lm(WeeklyCustomerSavings~+1+M+rho,data = udaje)
latex_table <- xtable(summary(regresia_vysledok), caption = "Seller's WeeklyCustomerSavings vs. M and Rho")

# Print LaTeX code in the console
#print(latex_table, include.rownames = FALSE, caption.placement = "top")

# Optionally export to a .tex file
write(print(latex_table, include.rownames = FALSE, caption.placement = "top"), 
      file = "summary_statistics.tex")
rm(latex_table)
